(() => {
"use strict";

const KEY = "focusflow_v1";
const todayISO = () => new Date().toISOString().slice(0,10);
const uid = (prefix="id") => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
const fmtDate = d => new Intl.DateTimeFormat(undefined,{weekday:"long",month:"long",day:"numeric",year:"numeric"}).format(d);
const shortDate = iso => { if(!iso)return "No due date"; const d=new Date(iso+"T00:00:00"); return d.toLocaleDateString(undefined,{month:"short",day:"numeric"}); };
const dateOffset = (n) => { const d=new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate()+n); return d.toISOString().slice(0,10); };
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const defaults = {
  profile:{name:"FocusFlow User",goal:60},
  theme:"system",
  tasks:[],
  sessions:[],
  habits:[],
  habitLogs:{},
  dailyStats:{},
  settingsSaved:false
};
let state = load();
let charts = {};
let timer = {mode:"focus", seconds: state.profile.defaultDuration*60 || 1500, running:false, interval:null, duration:state.profile.defaultDuration||25};

function load(){
  try { return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")}; }
  catch(e){ console.warn("FocusFlow data reset:",e); return {...defaults}; }
}
function save(){ localStorage.setItem(KEY,JSON.stringify(state)); }
function persist(){ save(); renderAll(); }
function el(id){return document.getElementById(id)}
function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function priorityWeight(p){return {critical:4,high:3,medium:2,low:1}[p]||1}
function isOverdue(t){return !t.completed && t.due && t.due < todayISO()}
function greeting(){const h=new Date().getHours();return h<12?"morning":h<17?"afternoon":"evening"}
function initials(name){return name.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join("").toUpperCase()||"FF"}

function init(){
  applyTheme();
  el("today-date").textContent=fmtDate(new Date());
  el("greeting-name").textContent=state.profile.name.split(" ")[0]||"there";
  el("profile-name").textContent=state.profile.name;
  el("top-profile").textContent=initials(state.profile.name);
  el("profile-btn").querySelector(".avatar").textContent=initials(state.profile.name);
  bindNavigation(); bindGlobal(); bindTaskEvents(); bindFocus(); bindHabits(); bindSettings();
  renderAll();
  setTimeout(()=>el("app-loader").style.display="none",350);
}
function bindNavigation(){
  document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>navigate(btn.dataset.section)));
  document.querySelectorAll("[data-section-link]").forEach(btn=>btn.addEventListener("click",()=>navigate(btn.dataset.sectionLink)));
  el("mobile-menu").addEventListener("click",()=>el("sidebar").classList.toggle("open"));
}
function navigate(section){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===`section-${section}`));
  document.querySelectorAll(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.section===section));
  const labels={dashboard:["Workspace","Dashboard"],tasks:["Workspace","Tasks"],focus:["Deep work","Focus Mode"],habits:["Consistency","Habits"],analytics:["Intelligence","Analytics"],settings:["Workspace","Settings"]};
  el("page-kicker").textContent=labels[section][0]; el("page-title").textContent=labels[section][1];
  el("sidebar").classList.remove("open");
  if(section==="analytics") setTimeout(renderCharts,50);
}
function bindGlobal(){
  el("theme-toggle").addEventListener("click",()=>setTheme(state.theme==="dark"?"light":"dark"));
  el("quick-add").addEventListener("click",()=>openTaskModal());
  el("add-task-btn").addEventListener("click",()=>openTaskModal());
  el("add-habit-btn").addEventListener("click",()=>openHabitModal());
  el("notification-btn").addEventListener("click",()=>{renderNotifications();openModal("notification-modal")});
  document.querySelectorAll(".close-modal").forEach(b=>b.addEventListener("click",closeModal));
  el("modal-backdrop").addEventListener("click",e=>{if(e.target.id==="modal-backdrop")closeModal()});
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
}
function applyTheme(){
  const t=state.theme==="system"?(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light"):state.theme;
  document.body.classList.toggle("dark",t==="dark");
  document.querySelectorAll("[data-theme-choice]").forEach(b=>b.classList.toggle("active",b.dataset.themeChoice===state.theme));
}
function setTheme(t){state.theme=t;save();applyTheme();toast("Theme updated","success")}
function getDayData(iso){
  if(!state.dailyStats[iso]) state.dailyStats[iso]={completed:0,focus:0,score:0};
  return state.dailyStats[iso];
}
function completedToday(){return state.tasks.filter(t=>t.completed && t.completedAt?.slice(0,10)===todayISO()).length}
function focusToday(){return state.sessions.filter(s=>s.date===todayISO() && s.type==="focus").reduce((a,s)=>a+s.minutes,0)}
function sessionsToday(){return state.sessions.filter(s=>s.date===todayISO() && s.type==="focus").length}
function habitConsistency(){
  if(!state.habits.length)return 0;
  let sum=0;
  state.habits.forEach(h=>{let done=0;for(let i=0;i<7;i++) if(state.habitLogs[`${h.id}_${dateOffset(-i)}`])done++;sum+=done/7});
  return Math.round(sum/state.habits.length*100);
}
function focusStreak(){
  let streak=0;
  for(let i=0;i<366;i++){const d=dateOffset(-i);const has=state.sessions.some(s=>s.date===d&&s.type==="focus"&&s.minutes>0); if(has)streak++; else break}
  return streak;
}
function productivityScore(){
  const total=state.tasks.length, completed=state.tasks.filter(t=>t.completed).length;
  const completion=total?completed/total*35:0;
  const focus=clamp(focusToday()/Math.max(1,state.profile.goal),0,1)*25;
  const streak=clamp(focusStreak()/7,0,1)*15;
  const overdue=state.tasks.filter(isOverdue).length;
  const overdueScore=15*(1-clamp(overdue/Math.max(5,total),0,1));
  const habit=habitConsistency()/100*10;
  return Math.round(clamp(completion+focus+streak+overdueScore+habit,0,100));
}
function updateDailySnapshot(){
  const d=getDayData(todayISO());
  d.completed=completedToday(); d.focus=focusToday(); d.score=productivityScore(); save();
}
function renderAll(){
  updateDailySnapshot();
  renderDashboard(); renderTasks(); renderFocus(); renderHabits(); renderSettings(); renderNotifications();
  el("task-nav-count").textContent=state.tasks.filter(t=>!t.completed).length;
  el("side-progress").textContent=`${completionRate()}%`; el("side-progress-bar").style.width=`${completionRate()}%`;
  const activePage=document.querySelector(".page.active")?.id;
  if(activePage==="section-analytics")renderCharts();
}
function completionRate(){
  const total=state.tasks.length;return total?Math.round(state.tasks.filter(t=>t.completed).length/total*100):0
}
function renderDashboard(){
  const total=state.tasks.length, done=state.tasks.filter(t=>t.completed).length, pending=total-done, score=productivityScore();
  el("stat-total").textContent=total; el("stat-completed").textContent=done; el("stat-focus").textContent=formatMinutes(focusToday()); el("stat-score").textContent=score;
  el("stat-total-sub").textContent=pending?`${pending} pending`:"Ready to plan";
  el("stat-completion-sub").textContent=`${completionRate()}% completion`;
  el("stat-focus-sub").textContent=`${sessionsToday()} session${sessionsToday()===1?"":"s"}`;
  el("stat-score-sub").textContent=score>=80?"Excellent momentum":score>=60?"Good momentum":"Build your momentum";
  el("score-ring-value").textContent=score;
  el("score-ring-value").parentElement.parentElement.style.background=`conic-gradient(var(--primary) ${score*3.6}deg,var(--surface-2) 0deg)`;
  const bars=[["Tasks",total?Math.round(done/total*100):0],["Focus",clamp(Math.round(focusToday()/Math.max(1,state.profile.goal)*100),0,100)],["Streak",clamp(Math.round(focusStreak()/7*100),0,100)],["Habits",habitConsistency()]];
  el("score-bars").innerHTML=bars.map(([n,v])=>`<div class="score-row"><span>${n}</span><i><em style="width:${v}%"></em></i><b>${v}</b></div>`).join("");
  const items=[...state.tasks].sort((a,b)=>(a.completed-b.completed)||(priorityWeight(b.priority)-priorityWeight(a.priority))).slice(0,5);
  el("dashboard-tasks").innerHTML=items.length?items.map(taskPreviewHTML).join(""):`<div class="empty-state"><strong>No tasks yet</strong><span>Add your first task to start your flow.</span></div>`;
  el("streak-value").textContent=focusStreak();el("streak-message").textContent=focusStreak()>0?"Momentum is building":"Start your streak today";el("streak-detail").textContent=focusStreak()>0?"Keep showing up for focused work.":"Complete a focus session to begin.";
  renderWeekDots();setTimeout(renderWeeklyChart,20);
}
function taskPreviewHTML(t){return `<div class="preview-task"><button class="check ${t.completed?"done":""}" data-complete="${t.id}">${t.completed?"✓":""}</button><div class="task-info"><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(t.category)} · ${shortDate(t.due)}</small></div><i class="priority-dot ${t.priority}"></i></div>`}
function renderWeekDots(){el("week-dots").innerHTML=Array.from({length:7},(_,i)=>{const iso=dateOffset(-6+i),has=state.sessions.some(s=>s.date===iso&&s.type==="focus");const label=new Date(iso+"T00:00:00").toLocaleDateString(undefined,{weekday:"narrow"});return `<div class="day-dot ${iso===todayISO()?"active":""}"><i>${has?"✓":""}</i><span>${label}</span></div>`}).join("")}
function renderTasks(){
  const q=el("task-search").value.toLowerCase().trim(),filter=el("task-filter").value,pf=el("priority-filter").value,sort=el("task-sort").value;
  let list=state.tasks.filter(t=>(!q||`${t.title} ${t.description} ${t.category}`.toLowerCase().includes(q))&&(filter==="all"||(filter==="pending"&&!t.completed)||(filter==="completed"&&t.completed)||(filter==="overdue"&&isOverdue(t)))&&(pf==="all"||t.priority===pf));
  if(sort==="due")list.sort((a,b)=>(a.due||"9999").localeCompare(b.due||"9999"));else if(sort==="priority")list.sort((a,b)=>priorityWeight(b.priority)-priorityWeight(a.priority));else if(sort==="created")list.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));else list.sort((a,b)=>(a.order??0)-(b.order??0));
  const container=el("task-list");
  container.innerHTML=list.length?list.map(taskRowHTML).join(""):`<div class="empty-state"><strong>${q||filter!=="all"||pf!=="all"?"No matching tasks":"Your task list is clear"}</strong><span>${q||filter!=="all"||pf!=="all"?"Try changing your filters.":"Add a task and make your next move count."}</span></div>`;
  container.querySelectorAll("[data-complete]").forEach(b=>b.addEventListener("click",()=>toggleTask(b.dataset.complete)));
  container.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>openTaskModal(b.dataset.edit)));
  container.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>deleteTask(b.dataset.delete)));
  container.querySelectorAll(".task-row").forEach(row=>{row.draggable=true;row.addEventListener("dragstart",()=>row.classList.add("dragging"));row.addEventListener("dragend",()=>{row.classList.remove("dragging");reorderTasks()});row.addEventListener("dragover",e=>{e.preventDefault();const dragging=container.querySelector(".dragging");if(dragging&&dragging!==row){const r=row.getBoundingClientRect();container.insertBefore(dragging,e.clientY-r.top<r.height/2?row:row.nextSibling)}})});
}
function taskRowHTML(t){return `<div class="task-row ${t.completed?"completed":""}" data-id="${t.id}"><div class="task-main"><button class="check ${t.completed?"done":""}" data-complete="${t.id}">${t.completed?"✓":""}</button><div><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(t.category)}${t.description?" · "+escapeHTML(t.description):""}</small></div></div><div><span class="badge ${t.priority}">${t.priority}</span></div><div class="${isOverdue(t)?"overdue":""}">${shortDate(t.due)}</div><div>${t.estimate||0}m</div><div>${t.completed?'<span class="badge low">Done</span>':isOverdue(t)?'<span class="badge critical">Overdue</span>':'<span class="badge medium">Pending</span>'}</div><div class="row-actions"><button title="Edit" data-edit="${t.id}">✎</button><button title="Delete" data-delete="${t.id}">×</button></div></div>`}
function reorderTasks(){const ids=[...el("task-list").querySelectorAll(".task-row")].map(x=>x.dataset.id);ids.forEach((id,i)=>{const t=state.tasks.find(x=>x.id===id);if(t)t.order=i});save();renderTasks()}
function bindTaskEvents(){["task-search","task-filter","priority-filter","task-sort"].forEach(id=>el(id).addEventListener("input",renderTasks));el("task-form").addEventListener("submit",saveTask)}
function openTaskModal(id=null){
  const t=id&&state.tasks.find(x=>x.id===id);
  el("task-modal-title").textContent=t?"Edit task":"Create task";el("task-id").value=t?.id||"";el("task-title").value=t?.title||"";el("task-description").value=t?.description||"";el("task-category").value=t?.category||"Work";el("task-priority").value=t?.priority||"medium";el("task-due").value=t?.due||todayISO();el("task-estimate").value=t?.estimate||30;openModal("task-modal");setTimeout(()=>el("task-title").focus(),100)
}
function saveTask(e){e.preventDefault();const id=el("task-id").value;const payload={title:el("task-title").value.trim(),description:el("task-description").value.trim(),category:el("task-category").value,priority:el("task-priority").value,due:el("task-due").value,estimate:Number(el("task-estimate").value)||30};if(!payload.title)return; if(id){Object.assign(state.tasks.find(t=>t.id===id),payload);toast("Task updated","success")}else{state.tasks.push({id:uid("task"),...payload,completed:false,createdAt:new Date().toISOString(),order:state.tasks.length});toast("Task created","success")}save();closeModal();renderAll()}
function toggleTask(id){const t=state.tasks.find(x=>x.id===id);if(!t)return;t.completed=!t.completed;t.completedAt=t.completed?new Date().toISOString():null;save();renderAll();if(t.completed){toast("Task completed — nice work!","success");confetti()}}
function deleteTask(id){const t=state.tasks.find(x=>x.id===id);if(!t)return;if(!confirm(`Delete "${t.title}"?`))return;state.tasks=state.tasks.filter(x=>x.id!==id);save();renderAll();toast("Task deleted")}
function formatMinutes(m){m=Math.round(m);if(m<60)return `${m}m`;const h=Math.floor(m/60),r=m%60;return `${h}h ${r?`${r}m`:""}`.trim()}

function bindFocus(){
  document.querySelectorAll(".mode-tab").forEach(b=>b.addEventListener("click",()=>setTimerMode(b.dataset.mode)));
  el("timer-toggle").addEventListener("click",toggleTimer);el("timer-reset").addEventListener("click",resetTimer);
  el("duration-range").addEventListener("input",e=>{timer.duration=Number(e.target.value);el("duration-output").textContent=`${timer.duration} min`;if(!timer.running&&timer.mode==="focus"){timer.seconds=timer.duration*60;renderTimer()}});
}
function setTimerMode(mode){if(timer.running)return;timer.mode=mode;timer.duration=mode==="focus"?Number(el("duration-range").value):mode==="short"?5:15;timer.seconds=timer.duration*60;document.querySelectorAll(".mode-tab").forEach(b=>b.classList.toggle("active",b.dataset.mode===mode));renderTimer()}
function toggleTimer(){timer.running?pauseTimer():startTimer()}
function startTimer(){if(timer.seconds<=0)resetTimer();timer.running=true;el("timer-toggle").textContent="Pause";el("timer-sub").textContent="Stay with the next minute";timer.interval=setInterval(()=>{timer.seconds--;renderTimer();if(timer.seconds<=0)finishTimer()},1000);renderTimer()}
function pauseTimer(){timer.running=false;clearInterval(timer.interval);el("timer-toggle").textContent="Resume";el("timer-sub").textContent="Paused — return when ready";renderTimer()}
function resetTimer(){timer.running=false;clearInterval(timer.interval);timer.seconds=timer.duration*60;el("timer-toggle").textContent=timer.mode==="focus"?"Start focus":"Start break";el("timer-sub").textContent="Ready when you are";renderTimer()}
function finishTimer(){clearInterval(timer.interval);timer.running=false;const mins=timer.duration;if(timer.mode==="focus"){state.sessions.push({id:uid("session"),date:todayISO(),type:"focus",minutes:mins,completedAt:new Date().toISOString()});getDayData(todayISO()).focus+=mins;toast(`Focus session complete: ${mins} minutes!`,"success");confetti();}else toast("Break complete — ready to go?","success");timer.seconds=timer.duration*60;el("timer-toggle").textContent=timer.mode==="focus"?"Start focus":"Start break";save();renderAll();renderTimer()}
function renderTimer(){const m=Math.floor(timer.seconds/60).toString().padStart(2,"0"),s=(timer.seconds%60).toString().padStart(2,"0");el("timer-display").textContent=`${m}:${s}`;el("timer-label").textContent=timer.mode==="focus"?"FOCUS":timer.mode==="short"?"SHORT BREAK":"LONG BREAK";const total=timer.duration*60;const pct=1-timer.seconds/total;document.querySelector(".timer-ring").style.background=`conic-gradient(var(--primary) ${pct*360}deg,var(--surface-2) 0deg)`;el("focus-session-count").textContent=sessionsToday();el("focus-minutes-today").textContent=formatMinutes(focusToday());el("focus-sessions-today").textContent=sessionsToday();el("focus-streak-today").textContent=focusStreak();el("recent-sessions").innerHTML=state.sessions.filter(s=>s.type==="focus").slice(-5).reverse().map(s=>`<div class="session-item"><span>${new Date(s.completedAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</span><strong>${s.minutes} min focus</strong></div>`).join("")||`<div class="empty-state"><span>No completed sessions yet.</span></div>`}
function renderFocus(){el("duration-range").value=timer.duration;el("duration-output").textContent=`${timer.duration} min`;renderTimer()}

function bindHabits(){el("habit-form").addEventListener("submit",saveHabit)}
function openHabitModal(){el("habit-form").reset();openModal("habit-modal");setTimeout(()=>el("habit-name").focus(),100)}
function saveHabit(e){e.preventDefault();const name=el("habit-name").value.trim();if(!name)return;state.habits.push({id:uid("habit"),name,color:el("habit-color").value,createdAt:new Date().toISOString()});save();closeModal();renderAll();toast("Habit added","success")}
function habitStreak(h){let n=0;for(let i=0;i<366;i++){if(state.habitLogs[`${h.id}_${dateOffset(-i)}`])n++;else break}return n}
function renderHabits(){
  el("habit-grid").innerHTML=state.habits.length?state.habits.map(h=>{const days=Array.from({length:7},(_,i)=>dateOffset(-6+i));return `<article class="panel habit-card"><div class="habit-top"><div class="habit-icon ${h.color}">↗</div><div><strong>${escapeHTML(h.name)}</strong><small>${habitStreak(h)} day streak</small></div><button class="habit-delete" data-habit-delete="${h.id}">×</button></div><div class="habit-streak"><b>${habitStreak(h)}</b> <span>consecutive days</span></div><div class="habit-days">${days.map(d=>`<button class="habit-day ${state.habitLogs[`${h.id}_${d}`]?"done":""} ${d===todayISO()?"today":""}" data-habit="${h.id}" data-day="${d}"><span>${new Date(d+"T00:00:00").toLocaleDateString(undefined,{weekday:"narrow"})}</span><i>${state.habitLogs[`${h.id}_${d}`]?"✓":""}</i></button>`).join("")}</div></article>`}).join(""):`<div class="panel empty-state" style="grid-column:1/-1"><strong>No habits yet</strong><span>Create one small repeatable action and track it here.</span></div>`;
  el("habit-grid").querySelectorAll("[data-habit]").forEach(b=>b.addEventListener("click",()=>toggleHabit(b.dataset.habit,b.dataset.day)));
  el("habit-grid").querySelectorAll("[data-habit-delete]").forEach(b=>b.addEventListener("click",()=>deleteHabit(b.dataset.habitDelete)));
}
function toggleHabit(id,day){const k=`${id}_${day}`;state.habitLogs[k]=!state.habitLogs[k];save();renderAll();if(state.habitLogs[k]){toast("Habit checked off","success");if(day===todayISO())confetti()}}
function deleteHabit(id){const h=state.habits.find(x=>x.id===id);if(h&&confirm(`Delete "${h.name}"?`)){state.habits=state.habits.filter(x=>x.id!==id);Object.keys(state.habitLogs).filter(k=>k.startsWith(id+"_")).forEach(k=>delete state.habitLogs[k]);save();renderAll();toast("Habit deleted")}}

function dailyArrays(){
  const labels=[],completed=[],focus=[],scores=[],rates=[];
  for(let i=6;i>=0;i--){const d=dateOffset(-i),dd=getDayData(d), created=state.tasks.filter(t=>t.createdAt?.slice(0,10)===d).length, done=state.tasks.filter(t=>t.completedAt?.slice(0,10)===d).length;labels.push(new Date(d+"T00:00:00").toLocaleDateString(undefined,{weekday:"short"}));completed.push(done);focus.push(state.sessions.filter(s=>s.date===d&&s.type==="focus").reduce((a,s)=>a+s.minutes,0));scores.push(dd.score||0);rates.push(created?Math.round(done/created*100):0)}
  return {labels,completed,focus,scores,rates}
}
function chartBase(){return {responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{color:"#8b90a1",font:{size:9}}},y:{grid:{color:"rgba(130,135,155,.12)"},ticks:{color:"#8b90a1",font:{size:9}}}}}}
function makeChart(id,type,data,options={}){const c=el(id);if(!c)return;if(charts[id])charts[id].destroy();charts[id]=new Chart(c,{type,data,options:{...chartBase(),...options}})}
function renderWeeklyChart(){const d=dailyArrays();makeChart("weeklyChart","bar",{labels:d.labels,datasets:[{label:"Tasks",data:d.completed,borderRadius:5,backgroundColor:"#6c5ce7",maxBarThickness:18},{label:"Focus",data:d.focus.map(x=>Math.round(x/10)),borderRadius:5,backgroundColor:"#20b486",maxBarThickness:18}]},{plugins:{legend:{display:true,labels:{boxWidth:7,font:{size:9},color:"#8b90a1"}}}})}
function renderCharts(){const d=dailyArrays();makeChart("tasksChart","bar",{labels:d.labels,datasets:[{data:d.completed,backgroundColor:"#6c5ce7",borderRadius:6,maxBarThickness:28}]});makeChart("focusChart","line",{labels:d.labels,datasets:[{data:d.focus,borderColor:"#20b486",backgroundColor:"#20b48622",fill:true,tension:.35,pointRadius:3}]});makeChart("scoreChart","line",{labels:d.labels,datasets:[{data:d.scores,borderColor:"#3987ee",backgroundColor:"#3987ee18",fill:true,tension:.35,pointRadius:3}]},{scales:{y:{min:0,max:100}}});const counts=["low","medium","high","critical"].map(p=>state.tasks.filter(t=>t.priority===p).length);makeChart("priorityChart","doughnut",{labels:["Low","Medium","High","Critical"],datasets:[{data:counts,backgroundColor:["#3987ee","#f59e0b","#f97316","#ef5b6b"],borderWidth:0}]},{cutout:"68%"});makeChart("completionChart","bar",{labels:d.labels,datasets:[{data:d.rates,backgroundColor:"#8577f2",borderRadius:6,maxBarThickness:28}]},{scales:{y:{min:0,max:100,ticks:{callback:v=>v+"%"}}}})}
function renderSettings(){el("settings-name").value=state.profile.name;el("settings-goal").value=state.profile.goal;applyTheme()}
function bindSettings(){
  el("save-settings").addEventListener("click",()=>{state.profile.name=el("settings-name").value.trim()||"FocusFlow User";state.profile.goal=clamp(Number(el("settings-goal").value)||60,15,1440);save();renderAll();toast("Settings saved","success")});
  document.querySelectorAll("[data-theme-choice]").forEach(b=>b.addEventListener("click",()=>setTheme(b.dataset.themeChoice)));
  el("clear-data").addEventListener("click",()=>{if(confirm("Clear every FocusFlow task, session, habit, and setting? This cannot be undone.")){localStorage.removeItem(KEY);state=load();save();renderAll();toast("All data cleared","success")}});
  el("reset-demo").addEventListener("click",loadDemo);
  el("export-btn").addEventListener("click",exportData);el("import-btn").addEventListener("click",()=>el("import-file").click());el("import-file").addEventListener("change",importData);
}
function loadDemo(){
  const now=new Date().toISOString();
  state.tasks=[
    {id:uid("task"),title:"Finish portfolio case study",description:"Polish the analytics story and publish the final version.",category:"Work",priority:"high",due:todayISO(),estimate:90,completed:false,createdAt:now,order:0},
    {id:uid("task"),title:"Review SQL interview questions",description:"Practice joins, CTEs and window functions.",category:"Study",priority:"critical",due:dateOffset(1),estimate:60,completed:false,createdAt:now,order:1},
    {id:uid("task"),title:"Plan tomorrow",description:"Choose three outcomes for tomorrow.",category:"Planning",priority:"medium",due:todayISO(),estimate:15,completed:true,completedAt:now,createdAt:now,order:2},
    {id:uid("task"),title:"30-minute walk",description:"Get outside and reset.",category:"Health",priority:"low",due:dateOffset(-1),estimate:30,completed:false,createdAt:now,order:3}
  ];
  state.sessions=[];for(let i=0;i<5;i++)state.sessions.push({id:uid("session"),date:dateOffset(-i),type:"focus",minutes:i===0?25:50,completedAt:new Date(Date.now()-i*86400000).toISOString()});
  state.habits=[{id:uid("habit"),name:"Read 20 pages",color:"purple",createdAt:now},{id:uid("habit"),name:"Morning planning",color:"green",createdAt:now},{id:uid("habit"),name:"Stretch",color:"orange",createdAt:now}];
  state.habitLogs={};state.habits.forEach(h=>{for(let i=0;i<7;i++)if((i+h.name.length)%3!==0)state.habitLogs[`${h.id}_${dateOffset(-i)}`]=true});
  save();renderAll();toast("Demo workspace loaded","success");navigate("dashboard")
}
function notifications(){
  const list=[];
  state.tasks.filter(isOverdue).slice(0,5).forEach(t=>list.push({icon:"!",title:"Overdue task",text:`${t.title} was due ${shortDate(t.due)}.`}));
  state.tasks.filter(t=>!t.completed&&t.due&&t.due>=todayISO()&&t.due<=dateOffset(1)).slice(0,5).forEach(t=>list.push({icon:"◷",title:"Upcoming deadline",text:`${t.title} is due ${t.due===todayISO()?"today":"tomorrow"}.`}));
  if(completedToday()>0)list.push({icon:"✓",title:"Great progress",text:`You've completed ${completedToday()} task${completedToday()===1?"":"s"} today.`});
  return list;
}
function renderNotifications(){const list=notifications();el("notification-dot").style.display=list.length?"block":"none";el("notification-list").innerHTML=list.length?list.map(n=>`<div class="notification-item"><div class="notification-icon">${n.icon}</div><div><strong>${n.title}</strong><p>${escapeHTML(n.text)}</p></div></div>`).join(""):`<div class="empty-state"><strong>You're all caught up</strong><span>No new notifications.</span></div>`}
function openModal(id){el("modal-backdrop").classList.add("open");document.querySelectorAll(".modal").forEach(m=>m.style.display="none");el(id).style.display="block"}
function closeModal(){el("modal-backdrop").classList.remove("open")}
function toast(message,type=""){const t=document.createElement("div");t.className=`toast ${type}`;t.textContent=message;el("toast-region").appendChild(t);setTimeout(()=>t.remove(),3000)}
function confetti(){const root=el("confetti");for(let i=0;i<22;i++){const x=document.createElement("i");x.style.left=Math.random()*100+"%";x.style.top="-10px";x.style.animationDelay=Math.random()*.25+"s";x.style.background=["#6c5ce7","#20b486","#f59e0b","#3987ee","#ef5b6b"][i%5];x.style.transform=`rotate(${Math.random()*360}deg)`;root.appendChild(x);setTimeout(()=>x.remove(),1400)}}
function exportData(){const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`focusflow-backup-${todayISO()}.json`;a.click();URL.revokeObjectURL(url);toast("Backup exported","success")}
function importData(e){const file=e.target.files[0];if(!file)return;const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);if(!data.tasks||!data.profile)throw Error();state={...defaults,...data};save();renderAll();toast("Backup imported","success")}catch{toast("Invalid FocusFlow backup","error")}e.target.value=""};r.readAsText(file)}
document.addEventListener("click",e=>{const c=e.target.closest("[data-complete]");if(c&&c.closest("#dashboard-tasks"))toggleTask(c.dataset.complete)});
init();
})();